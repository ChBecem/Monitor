# 👶 Historique de Conception - Baby Monitor Intelligent

Ce document regroupe l'historique complet, les spécifications cliniques et le cahier des charges de l'application **Baby Monitor Intelligent**, initialement discutés dans l'espace de l'application de stock. Il est maintenant centralisé ici pour servir de référence à l'agent IA et à l'utilisateur.

---

## 📌 1. Vue d'Ensemble du Projet
L'objectif est de concevoir un moniteur de bébé moderne, chaleureux et sécurisé, combinant une surveillance sonore en temps réel et une analyse visuelle avancée basée sur la puissance de l'IA **Gemini 3.5-Flash**.

### Objectifs Clés :
1. **Éviter la mort subite du nourrisson (MSN) :** Analyse par vision de la position de sommeil (dos recommandé, ventre déconseillé) et détection d'obstacles dans le berceau (boules de tissus, jouets, peluches).
2. **Surveillance Acoustique Directe :** Écoute du flux audio depuis le micro physique ou simulé, calcul en décibels (dBA) et alerte intelligente en cas de pleurs ou de cris prolongés.
3. **Apaisement Actif :** Machine à bruits blancs optimisée (bruit rose de vagues, pulsations cardiaques intra-utérines simulées par synthèse de fréquences pures, mélodies douces) avec minuterie.
4. **Journal de Soins Intégré (Care Logger) :** Enregistrement des moments d'alimentation, de changement de couche, et graphiques de durée des cycles circadiens de sommeil.

---

## 💬 2. Synthèse de la Discussion & Demandes Initiales (Transférées)

### Échange 1 : La Vision & La Détection des Postures
* **Bessem :** *"Je veux que l'application puisse filmer le bébé dans son lit et me dire s'il est en danger. Les pédiatres disent toujours qu'il doit dormir sur le dos et que le lit doit être vide."*
* **Solution IA :** Intégration d'un capteur de vision qui prend des clichés du lit (simulation de scénarios prédéfinis ou webcam réelle du parent) et les envoie à l'API Gemini. Gemini retourne une fiche pédiatrique complète au format JSON contenant :
  * Un niveau de sécurité (`SAFE`, `WARNING`, `CRITICAL`).
  * Une description textuelle de la posture pour rassurer le parent.
  * Une analyse d'encombrement du lit.
  * Des conseils de prévention directe.

### Échange 2 : Le Détecteur de Décibels (dBA)
* **Bessem :** *"Est-ce que l'application peut écouter le bruit dans la chambre ? Parfois les bébés pleurent fort. Il faut un signal visuel rouge vibrant si ça dépasse un certain seuil de sensibilité."*
* **Solution IA :** Conception du module `AudioVisualizer` :
  * Utilise l'API Web Audio pour récupérer le flux du microphone réel.
  * Analyse des amplitudes en RMS et conversion en décibels.
  * Squelch et seuil de déclenchement réglable par réglette de sensibilité (ex: alerte si volume > 65 dBA pendant plus de 1,5 seconde).
  * Mode simulateur interactif intégré (permet de simuler des pleurs d'un clic pour tester l'alerte même sans micro connecté).

### Échange 3 : La Machine de Transition de Sommeil
* **Bessem :** *"Je veux que l'application puisse jouer des bruits apaisants comme le son du ventre de la maman ou de la pluie pour aider le bébé à dormir, avec un bouton pour que ça s'arrête tout seul après 15 minutes."*
* **Solution IA :** Conception du module `LullabyPlayer` :
  * Synthétiseur audio pur (Web Audio API) pour générer du bruit rose (simulant de l'eau/pluie enveloppante) en appliquant des filtres passifs à 550Hz.
  * Synthèse de vagues de pulsations cardiaques à 66 BPM imitant le flux placentaire.
  * Générateur de carillon de berceuse traditionnelle avec des ondes sinusoïdales à déclin exponentiel.
  * Minuterie réglable (1, 5, 15, ou 30 min) qui éteint les générateurs en douceur sans clic brusque.

### Échange 4 : Suivi circadien & Graphiques
* **Bessem :** *"Je veux pouvoir noter l'heure à laquelle le bébé mange et dort, pour le montrer au pédiatre."*
* **Solution IA :** Module `CareLogger` incluant :
  * Chronomètre de sommeil persistant dans le navigateur.
  * Raccourcis pour l'allaitement (120ml) et le change de couche.
  * Composant de graphique vectoriel SVG affichant l'historique horaire hebdomadaire de sommeil pour détecter les habitudes de l'enfant.

---

## 🛠️ 3. Spécifications Techniques Actuelles

* **Framework :** React 19 + TypeScript + Vite.
* **Serveur Back-end :** Express.js avec proxy sécurisé de clé API Gemini (`/api/gemini/analyze`) sur le modèle standardisé `gemini-3.5-flash`.
* **Animations :** Motion (de `motion/react`) pour les transitions d'alertes fluides.
* **Icônes :** Lucide-React.
* **Persistance :** Sauvegarde locale via `localStorage` pour les journaux d'événements et les mesures circadiennes d'une session à l'autre.
* **Design :** Thème sombre haut de gamme, aux contrastes soignés noir minéral et vert émeraude, idéal pour être posé en veilleuse sur la table de nuit d'une chambre d'enfant.
