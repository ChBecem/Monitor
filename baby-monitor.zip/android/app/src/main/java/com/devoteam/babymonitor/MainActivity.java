package com.devoteam.babymonitor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
