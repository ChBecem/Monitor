import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let aiInstance: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("La clé d'API GEMINI_API_KEY n'est pas configurée dans les secrets de l'application.");
    }
    aiInstance = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// In-memory sessions storage for real-time baby monitor synchronization fallback
const dbSessions = new Map<string, any>();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Support large base64 payloads (for audio clips / video frame streams)
  app.use(express.json({ limit: "15mb" }));

  // ---fallback API ENDPOINTS ---
  app.get("/api/sessions/:id", (req, res) => {
    const session = dbSessions.get(req.params.id);
    if (!session) {
      return res.status(404).json({ error: "Session non trouvée" });
    }
    res.json(session);
  });

  app.post("/api/sessions/:id", (req, res) => {
    const existing = dbSessions.get(req.params.id) || {};
    const updated = {
      ...existing,
      ...req.body,
      updatedAt: new Date().toISOString()
    };
    dbSessions.set(req.params.id, updated);
    res.json(updated);
  });

  app.delete("/api/sessions/:id", (req, res) => {
    dbSessions.delete(req.params.id);
    res.json({ success: true });
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", activeSessions: dbSessions.size });
  });

  app.post("/api/gemini/analyze", async (req, res) => {
    try {
      const { imageData, mimeType, scenarioName } = req.body;
      if (!imageData) {
        return res.status(400).json({ error: "Image non fournie." });
      }

      const client = getGeminiClient();
      let base64Data = imageData;
      if (base64Data.includes(",")) {
        base64Data = base64Data.split(",")[1];
      }

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType || "image/jpeg",
            },
          },
          {
            text: `Vous êtes un expert pédiatrique en sécurité de sommeil des nourrissons français. Examinez cette vue caméra du berceau. Le scénario est : "${scenarioName || "Surveillance en direct"}".
Analyse la posture du bébé pour s'assurer qu'il dort de manière recommandée (sur le dos) et sans danger (pas d'encombrement du berceau comme des peluches, des couettes de lit amples, des oreillers, etc.).
Retourne les résultats sous la forme du schéma JSON requis contenant :
1. safetyRating : 'SAFE' (si sur le dos, visage dégagé, berceau vide et sûr), 'WARNING' (si sur le ventre mais sans étouffement immédiat, ou présence de peluches/encombrements gérables), ou 'CRITICAL' (si voies respiratoires masquées, doudou sur le visage, ou situation d'étouffement imminente).
2. postureText : Description clinique de sa posture en français.
3. cribAssoc : Objets, draps ou jouets repérés et leur niveau d'encombrement en français.
4. environmentalAdvice : Conseils pédagogiques basés sur la prévention de la Mort Subite du Nourrisson (MSN) en français.
5. estimatedState : État général détecté (Endormi, Réveillé, Pleurs, Risk).
6. recommendations : Liste d'actions précises en français pour les parents.`
          }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              safetyRating: {
                type: Type.STRING,
                description: "Safety rating value. Must be SAFE, WARNING, or CRITICAL.",
                enum: ["SAFE", "WARNING", "CRITICAL"],
              },
              postureText: {
                type: Type.STRING,
                description: "Description of infant posture in French.",
              },
              cribAssoc: {
                type: Type.STRING,
                description: "Crib environment objects analysis in French.",
              },
              environmentalAdvice: {
                type: Type.STRING,
                description: "Clinical prevention SIDS advice in French.",
              },
              estimatedState: {
                type: Type.STRING,
                description: "Overall predicted state in French.",
              },
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.STRING,
                },
                description: "Precise recommendations list in French.",
              },
            },
            required: [
              "safetyRating",
              "postureText",
              "cribAssoc",
              "environmentalAdvice",
              "estimatedState",
              "recommendations",
            ],
          },
        },
      });

      if (!response.text) {
        throw new Error("L'API Gemini n'a pas renvoyé de texte.");
      }

      const cleanJson = response.text.trim();
      res.json(JSON.parse(cleanJson));
    } catch (err: any) {
      console.warn("Erreur d'analyse de l'IA pédiatrique :", err);
      res.status(500).json({ error: err?.message || "Erreur de communication avec l'intelligence Gemini." });
    }
  });

  // --- VITE MIDDLEWARE SETUP ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware integrated.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving production static assets.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
