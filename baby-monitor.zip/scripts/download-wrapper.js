import * as https from 'https';
import * as fs from 'fs';
import * as path from 'path';

const fileUrl = 'https://raw.githubusercontent.com/gradle/gradle/v8.14.3/gradle/wrapper/gradle-wrapper.jar';
const destPath = path.resolve('android', 'gradle', 'wrapper', 'gradle-wrapper.jar');

console.log(`[Gradle Fix] Téléchargement du fichier gradle-wrapper.jar authentique...`);
console.log(`[Gradle Fix] Source : ${fileUrl}`);
console.log(`[Gradle Fix] Destination : ${destPath}`);

const dir = path.dirname(destPath);
if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir, { recursive: true });
}

const file = fs.createWriteStream(destPath);

https.get(fileUrl, (response) => {
  if (response.statusCode !== 200) {
    console.error(`[Gradle Fix] Échec du téléchargement: Code statut ${response.statusCode}`);
    process.exit(1);
  }
  
  response.pipe(file);
  
  file.on('finish', () => {
    file.close();
    const stats = fs.statSync(destPath);
    console.log(`[Gradle Fix] Succès : Téléchargement terminé sans corruption ! (${stats.size} octets)`);
  });
}).on('error', (err) => {
  fs.unlink(destPath, () => {});
  console.error(`[Gradle Fix] Une erreur s'est produite : ${err.message}`);
  process.exit(1);
});
