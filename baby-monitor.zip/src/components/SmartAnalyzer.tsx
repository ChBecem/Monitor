import React, { useEffect, useRef, useState } from "react";
import { Camera, RefreshCw, ShieldCheck, AlertTriangle, XOctagon, Sparkles, AlertCircle, Eye, RefreshCw as RotateCw } from "lucide-react";
import { AiAnalysisResult, SafetyRating } from "../types";

interface SmartAnalyzerProps {
  isCryingSimulatedFromVisual?: boolean;
  onCryingStateTriggeredBySimulator?: (isCrying: boolean) => void;
  isBabyStationView?: boolean;
  isParentView?: boolean;
  liveSessionSessionCode?: string | null;
  syncedBabyStateFromParent?: any; // Telemeters received from the server
  onLocalAnalysisComplete?: (result: AiAnalysisResult) => void; // Tell App to save local analysis
  triggerRemoteAnalysisRequest?: boolean; // Signal from parent to run a scan
}

export default function SmartAnalyzer({
  isCryingSimulatedFromVisual = false,
  onCryingStateTriggeredBySimulator,
  isBabyStationView = false,
  isParentView = false,
  liveSessionSessionCode = null,
  syncedBabyStateFromParent = null,
  onLocalAnalysisComplete,
  triggerRemoteAnalysisRequest = false
}: SmartAnalyzerProps) {
  const [activePresetId, setActivePresetId] = useState("dos_sain");
  const [useWebcam, setUseWebcam] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AiAnalysisResult | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Simulation presets definitions
  const PRESETS = [
    {
      id: "dos_sain",
      name: "Dors sur le dos (Recommandé)",
      desc: "Nouveau-né allongé sur le dos, berceau dégagé. Conditions recommandées par les pédiatres.",
      rating: SafetyRating.SAFE,
      draw: (ctx: CanvasRenderingContext2D) => {
        ctx.fillStyle = "#1e293b";
        ctx.fillRect(0, 0, 400, 300);

        ctx.strokeStyle = "#334155";
        ctx.lineWidth = 3;
        for (let i = 25; i < 400; i += 45) {
          ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 300); ctx.stroke();
        }

        ctx.fillStyle = "#ffffff";
        ctx.beginPath(); ctx.roundRect(40, 50, 320, 220, 16); ctx.fill();

        ctx.fillStyle = "#e0f2fe";
        ctx.beginPath(); ctx.roundRect(40, 180, 320, 90, [0, 0, 16, 16]); ctx.fill();

        ctx.fillStyle = "#fed7aa";
        ctx.beginPath(); ctx.arc(200, 110, 22, 0, Math.PI * 2); ctx.fill();

        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(192, 110, 3, 0, Math.PI, false); ctx.stroke();
        ctx.beginPath(); ctx.arc(208, 110, 3, 0, Math.PI, false); ctx.stroke();
        ctx.beginPath(); ctx.arc(200, 118, 2, 0, Math.PI, false); ctx.stroke();

        ctx.fillStyle = "#bbf7d0";
        ctx.beginPath(); ctx.roundRect(172, 132, 56, 80, 12); ctx.fill();

        ctx.fillStyle = "#fed7aa";
        ctx.beginPath();
        ctx.arc(165, 142, 5, 0, Math.PI * 2);
        ctx.arc(235, 142, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#10b981";
        ctx.font = "bold 11px system-ui";
        ctx.fillText("✓ Matelas homologué dégagé", 60, 80);
      }
    },
    {
      id: "ventre_hazard",
      name: "Sommeil sur le ventre (Attention)",
      desc: "Le nourrisson s'est retourné sur le ventre de lui-même. Vigilance active requise.",
      rating: SafetyRating.WARNING,
      draw: (ctx: CanvasRenderingContext2D) => {
        ctx.fillStyle = "#0f172a";
        ctx.fillRect(0, 0, 400, 300);

        ctx.strokeStyle = "#1e293b";
        ctx.lineWidth = 3;
        for (let i = 25; i < 400; i += 45) {
          ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 300); ctx.stroke();
        }

        ctx.fillStyle = "#f8fafc";
        ctx.beginPath(); ctx.roundRect(40, 50, 320, 220, 16); ctx.fill();

        ctx.fillStyle = "#fae8ff";
        ctx.beginPath(); ctx.roundRect(40, 180, 320, 90, [0, 0, 16, 16]); ctx.fill();

        ctx.fillStyle = "#f5d0fe";
        ctx.beginPath(); ctx.roundRect(170, 110, 60, 95, 12); ctx.fill();

        ctx.fillStyle = "#78350f"; 
        ctx.beginPath(); ctx.arc(200, 100, 22, 0, Math.PI * 2); ctx.fill();

        ctx.fillStyle = "#fed7aa"; 
        ctx.beginPath(); ctx.arc(190, 102, 9, 0, Math.PI * 2); ctx.fill();

        // Stuffed toy (danger)
        ctx.fillStyle = "#f59e0b"; 
        ctx.beginPath();
        ctx.arc(80, 90, 14, 0, Math.PI * 2); // Body
        ctx.arc(80, 72, 10, 0, Math.PI * 2); // Head
        ctx.fill();

        ctx.fillStyle = "#f43f5e"; 
        ctx.beginPath(); ctx.arc(310, 125, 12, 0, Math.PI * 2); ctx.fill();

        ctx.fillStyle = "#babaaa";
        ctx.font = "bold 11px system-ui";
        ctx.fillText("⚠ Peluche / Jouet dans le lit", 60, 240);
      }
    },
    {
      id: "couverture_hazard",
      name: "Drap recouvrant le visage (Critique)",
      desc: "Une couverture ample ou un doudou recouvre les voies respiratoires du bébé.",
      rating: SafetyRating.CRITICAL,
      draw: (ctx: CanvasRenderingContext2D) => {
        ctx.fillStyle = "#2d0606";
        ctx.fillRect(0, 0, 400, 300);

        ctx.strokeStyle = "#4d0000";
        ctx.lineWidth = 3;
        for (let i = 25; i < 400; i += 45) {
          ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 300); ctx.stroke();
        }

        ctx.fillStyle = "#fff5f5";
        ctx.beginPath(); ctx.roundRect(40, 50, 320, 220, 16); ctx.fill();

        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath(); ctx.roundRect(170, 120, 60, 80, 12); ctx.fill();

        // Giant sheet covering baby head
        ctx.fillStyle = "#fca5a5"; 
        ctx.beginPath(); ctx.roundRect(90, 80, 220, 150, 20); ctx.fill();

        ctx.strokeStyle = "#ef4444";
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(100, 110); ctx.lineTo(300, 110);
        ctx.moveTo(100, 150); ctx.lineTo(300, 150);
        ctx.stroke();

        ctx.fillStyle = "#b91c1c";
        ctx.font = "bold 11px system-ui";
        ctx.fillText("✖ ÉTOUFFEMENT : VOIE RESPIRATOIRE MASQUÉE", 50, 255);
      }
    },
    {
      id: "pleurs_nighttime",
      name: "Pleurs & Détresse nocturne",
      desc: "Le nourrisson s'est réveillé brusquement, en pleurant, les bras ouverts.",
      rating: SafetyRating.WARNING,
      draw: (ctx: CanvasRenderingContext2D) => {
        ctx.fillStyle = "#030712";
        ctx.fillRect(0, 0, 400, 300);

        ctx.strokeStyle = "#1e293b";
        ctx.lineWidth = 3;
        for (let i = 25; i < 400; i += 45) {
          ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 300); ctx.stroke();
        }

        ctx.fillStyle = "#cbd5e1";
        ctx.beginPath(); ctx.roundRect(40, 50, 320, 220, 16); ctx.fill();

        ctx.fillStyle = "#fdba74";
        ctx.beginPath(); ctx.roundRect(40, 195, 320, 75, [0, 0, 16, 16]); ctx.fill();

        // Crying red face
        ctx.fillStyle = "#fecaac"; 
        ctx.beginPath(); ctx.arc(200, 105, 23, 0, Math.PI * 2); ctx.fill();

        ctx.strokeStyle = "#334155";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(188, 102); ctx.lineTo(194, 100);
        ctx.moveTo(206, 100); ctx.lineTo(212, 102);
        ctx.stroke();

        ctx.fillStyle = "#3a0909";
        ctx.beginPath(); ctx.arc(200, 117, 7, 0, Math.PI * 2); ctx.fill();

        ctx.fillStyle = "#38bdf8"; // tears
        ctx.beginPath();
        ctx.arc(188, 108, 2.5, 0, Math.PI * 2);
        ctx.arc(212, 108, 2.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = "rgba(220, 38, 38, 0.4)";
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(200, 115, 35, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.arc(200, 115, 55, 0, Math.PI * 2); ctx.stroke();
      }
    }
  ];

  // Redraw preset on changes
  useEffect(() => {
    if (useWebcam) {
      startWebcam();
    } else {
      stopWebcam();
      drawPreset();
    }
    return () => stopWebcam();
  }, [activePresetId, useWebcam, isBabyStationView, isParentView]);

  // Support remote control analysis trigger sent by parent
  useEffect(() => {
    if (triggerRemoteAnalysisRequest && isBabyStationView && !isAnalyzing) {
      console.log("Remotely triggered sleep analysis activated on baby station!");
      triggerAiAnalysis();
    }
  }, [triggerRemoteAnalysisRequest]);

  const drawPreset = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const preset = PRESETS.find((p) => p.id === activePresetId);
    if (preset) {
      preset.draw(ctx);
    }
  };

  const startWebcam = async () => {
    try {
      setErrorText(null);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 400, height: 300 } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err: any) {
      setErrorText("Webcam non disponible ou accès refusé. Scénarios virtuels activés.");
      setUseWebcam(false);
    }
  };

  const stopWebcam = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  const triggerAiAnalysis = async () => {
    setIsAnalyzing(true);
    setErrorText(null);
    if (!isBabyStationView && !isParentView) {
      setAnalysisResult(null);
    }

    try {
      const canvas = canvasRef.current;
      if (!canvas) throw new Error("Éléments graphiques de capture inaccessibles.");
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Impossible de lier le processeur graphique.");

      // Snap video frame if webcam is active
      if (useWebcam && videoRef.current) {
        ctx.drawImage(videoRef.current, 0, 0, 400, 300);
      }

      const dataUrl = canvas.toDataURL("image/jpeg", 0.75);
      const preset = PRESETS.find((p) => p.id === activePresetId);
      const payload = {
        imageData: dataUrl,
        mimeType: "image/jpeg",
        scenarioName: useWebcam ? "Moniteur vidéo parent en direct" : preset?.name,
      };

      const response = await fetch("/api/gemini/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error("L'intelligence pédiatrique est temporairement indisponible.");
      }

      const result: AiAnalysisResult = await response.json();
      
      // Save locally or report state back
      setAnalysisResult(result);
      if (onLocalAnalysisComplete) {
        onLocalAnalysisComplete(result);
      }

      // Sync crying simulated back as well
      if (activePresetId === "pleurs_nighttime" && !useWebcam) {
        if (onCryingStateTriggeredBySimulator) onCryingStateTriggeredBySimulator(true);
      } else {
        const stateLower = (result.estimatedState || "").toLowerCase();
        const isCrying = stateLower.includes("pleur") || stateLower.includes("cry") || stateLower.includes("detresse");
        if (onCryingStateTriggeredBySimulator) onCryingStateTriggeredBySimulator(isCrying);
      }

    } catch (err: any) {
      console.warn("AI analyze failure:", err);
      setErrorText("L'appel à l'API de diagnostic pédiatrique Gemini a échoué. Veuillez vérifier la connexion.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const currentPreset = PRESETS.find((p) => p.id === activePresetId);

  // ==========================================
  // RENDER FOR PARENT VIEW ROOM ONLY
  // ==========================================
  if (isParentView) {
    const parentResult = syncedBabyStateFromParent;
    const hasAnyDiagnosis = parentResult && parentResult.safetyRating;

    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl h-full flex flex-col justify-between" id="parent-smart-analyzer-panel">
        <div>
          <span className="text-xs font-mono uppercase tracking-widest text-[#10b981]">Rapport de sécurité IA</span>
          <h3 className="text-lg font-bold tracking-tight mt-0.5 mb-1.5">Diagnostique de Couchage</h3>
          <p className="text-[11px] text-slate-400 mb-4">
            Données remises par l'intelligence artificielle Gemini en auscultant l'unité du berceau.
          </p>

          {!hasAnyDiagnosis ? (
            <div className="bg-slate-950/40 border border-slate-800 rounded-2xl p-6 text-center">
              <Sparkles className="h-8 w-8 text-slate-600 mx-auto mb-3 animate-pulse" />
              <h4 className="text-xs font-bold text-slate-350">En attente d'Analyse d'image</h4>
              <p className="text-[11px] text-slate-500 max-w-xs mx-auto mt-1">
                La station bébé n'a pas encore émis de bilan pédiatrique automatique récent.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Rating Banner */}
              <div className={`p-4 rounded-2xl border flex items-center gap-3.5 ${
                parentResult.safetyRating === SafetyRating.SAFE
                  ? "bg-emerald-950/30 border-emerald-500/30 text-emerald-300"
                  : parentResult.safetyRating === SafetyRating.WARNING
                  ? "bg-amber-950/30 border-amber-500/30 text-amber-300"
                  : "bg-red-950/30 border-red-500/30 text-red-300 animate-pulse"
              }`}>
                <div className="p-2.5 bg-slate-900/60 rounded-xl">
                  {parentResult.safetyRating === SafetyRating.SAFE && <ShieldCheck className="h-5 w-5 text-emerald-400" />}
                  {parentResult.safetyRating === SafetyRating.WARNING && <AlertTriangle className="h-5 w-5 text-amber-400" />}
                  {parentResult.safetyRating === SafetyRating.CRITICAL && <AlertCircle className="h-5 w-5 text-red-400" />}
                </div>
                <div>
                  <div className="text-[10px] font-mono uppercase text-slate-400">QUALIFIÉ PAR L'IA :</div>
                  <div className="text-sm font-bold tracking-tight capitalize">Lit {parentResult.safetyRating?.toLowerCase()}</div>
                </div>
              </div>

              {/* Text Fields */}
              <div className="space-y-3 font-sans">
                <div>
                  <span className="text-[9.5px] font-mono uppercase text-slate-500 block">Position Détectée :</span>
                  <p className="text-xs mt-0.5 text-white font-medium">{parentResult.postureText}</p>
                </div>

                <div>
                  <span className="text-[9.5px] font-mono uppercase text-slate-500 block">Environnement du Berceau :</span>
                  <p className="text-xs mt-0.5 text-slate-300">{parentResult.cribAssoc}</p>
                </div>

                <div className="p-3 bg-teal-950/20 border border-teal-500/10 rounded-xl">
                  <span className="text-[9.5px] font-mono uppercase text-teal-400 block font-semibold">Conseils Prévention Mort Subite :</span>
                  <p className="text-xs text-teal-100/90 leading-relaxed mt-0.5 font-medium">{parentResult.environmentalAdvice}</p>
                </div>

                {parentResult.recommendations && parentResult.recommendations.length > 0 && (
                  <div>
                    <span className="text-[9.5px] font-mono uppercase text-slate-500 block">Directives de Sécurité :</span>
                    <ul className="list-disc list-inside text-xs text-slate-350 space-y-1 mt-1 pl-1">
                      {parentResult.recommendations.map((rec: string, i: number) => (
                        <li key={i} className="leading-tight">{rec}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Small debug foot */}
        {hasAnyDiagnosis && (
          <div className="mt-5 pt-3 border-t border-slate-800 text-[10px] font-mono text-slate-500 flex justify-between">
            <span>État estimé : <strong>{parentResult.estimatedState || "NC"}</strong></span>
            <span>Unité Bébé Appairée ✓</span>
          </div>
        )}
      </div>
    );
  }

  // ==========================================
  // RENDER FOR BABY STATION TRANSMITTER
  // ==========================================
  if (isBabyStationView) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl h-full flex flex-col justify-between" id="baby-station-transmitter">
        <div>
          <span className="text-xs font-mono uppercase tracking-widest text-[#10b981]">TRANSVERSAL STUDIO</span>
          <h3 className="text-lg font-bold tracking-tight mt-0.5 mb-1">Optique Bébé Intelligent</h3>
          <p className="text-[11px] text-slate-400 mb-4">
            Simule ou capture la vue du berceau. L'IA auscultera le flux et les postures de sécurité.
          </p>

          {/* Canvas container */}
          <div className="relative w-full aspect-[4/3] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-inner">
            {useWebcam && (
              <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" playsInline muted />
            )}

            <canvas
              ref={canvasRef}
              width={400}
              height={300}
              className={`w-full h-full object-cover block ${useWebcam ? "hidden" : "block"}`}
            />

            {!useWebcam && currentPreset && (
              <div className="absolute top-3 left-3 z-10">
                <span className={`px-2 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider border shadow p-1 flex items-center gap-1 ${
                  currentPreset.rating === SafetyRating.SAFE
                    ? "bg-emerald-950/90 text-emerald-400 border-emerald-500/30"
                    : currentPreset.rating === SafetyRating.WARNING
                    ? "bg-amber-950/90 text-amber-400 border-amber-500/30"
                    : "bg-red-950/90 text-red-400 border-red-500/30"
                }`}>
                  {currentPreset.rating}
                </span>
              </div>
            )}

            {isAnalyzing && (
              <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-xs flex flex-col items-center justify-center z-20">
                <RefreshCw className="h-8 w-8 text-emerald-400 animate-spin mb-2" />
                <span className="text-xs font-bold font-mono text-white animate-pulse">Calcul de posture Gemini...</span>
              </div>
            )}
          </div>

          <div className="mt-4 flex flex-col gap-2">
            <button
              onClick={() => setUseWebcam(!useWebcam)}
              className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl text-xs font-semibold border transition-all ${
                useWebcam
                  ? "bg-[#10b981] text-white border-teal-500 shadow-md"
                  : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"
              }`}
            >
              <Camera className="h-4 w-4" />
              {useWebcam ? "Désactiver Webcam parent (Virtuel)" : "Activer ma vraie Webcam parent"}
            </button>

            {/* If virtual mode, allow toggling presets to test various baby postures */}
            {!useWebcam && (
              <div className="grid grid-cols-2 gap-1.5 mt-2">
                {PRESETS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setActivePresetId(p.id);
                      setAnalysisResult(null);
                    }}
                    className={`py-1.5 px-2.5 rounded-lg border text-left text-[10px] transition-all truncate ${
                      activePresetId === p.id
                        ? "bg-teal-950 border-teal-500/50 text-white font-medium"
                        : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800"
                    }`}
                  >
                    🎯 {p.name.replace(" (Recommandé)", "").replace(" (Attention)", "").replace(" (Critique)", "")}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="pt-3.5 mt-4 border-t border-slate-800 text-center">
          <button
            onClick={triggerAiAnalysis}
            disabled={isAnalyzing}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-white text-slate-900 hover:bg-slate-100 rounded-xl text-xs font-bold shadow transition-all disabled:opacity-50"
          >
            <Sparkles className="h-4 w-4 text-emerald-500" />
            Lancer l'analyse intelligente locaux
          </button>
        </div>
      </div>
    );
  }

  // ==========================================
  // RENDER FOR SINGLE-DEVICE ALL-IN-ONE SCREEN
  // ==========================================
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-6" id="smart-analyzer-all-in-one">
      <div className="lg:col-span-6 flex flex-col justify-between">
        <div>
          <span className="text-xs font-mono uppercase tracking-widest text-[#10b981]">Analyse vision IA</span>
          <h3 className="text-lg font-bold tracking-tight mt-0.5 mb-1">Capteur Vision HD</h3>
          <p className="text-[11px] text-slate-400 mb-4">Simulez ou capturez une vue du lit bébé pour détecter l'encombrement du berceau.</p>
        </div>

        <div className="relative w-full aspect-[4/3] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800">
          {useWebcam && (
            <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" playsInline muted />
          )}

          <canvas
            ref={canvasRef}
            width={400}
            height={300}
            className={`w-full h-full object-cover block ${useWebcam ? "hidden" : "block"}`}
          />

          {!useWebcam && currentPreset && (
            <div className="absolute top-3 left-3 z-10">
              <span className={`px-2 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider border shadow p-1 flex items-center gap-1 ${
                currentPreset.rating === SafetyRating.SAFE
                  ? "bg-emerald-950/90 text-emerald-400 border-emerald-500/30"
                  : currentPreset.rating === SafetyRating.WARNING
                  ? "bg-amber-950/90 text-amber-400 border-amber-500/30"
                  : "bg-red-950/90 text-red-400 border-red-500/30"
              }`}>
                {currentPreset.rating}
              </span>
            </div>
          )}

          {isAnalyzing && (
            <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-xs flex flex-col items-center justify-center z-20">
              <RotateCw className="h-8 w-8 text-emerald-400 animate-spin mb-2" />
              <span className="text-xs font-bold font-mono text-white animate-pulse">Analyse Gemini...</span>
            </div>
          )}
        </div>

        <div className="mt-4 flex flex-col sm:flex-row gap-2">
          <button
            onClick={() => setUseWebcam(!useWebcam)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
              useWebcam
                ? "bg-teal-600 border-teal-500 text-white"
                : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"
            }`}
          >
            <Camera className="h-3.5 w-3.5" />
            {useWebcam ? "Quitter la Webcam" : "Activer ma vraie Webcam"}
          </button>

          <button
            onClick={triggerAiAnalysis}
            disabled={isAnalyzing}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-white text-slate-900 hover:bg-slate-100 rounded-xl text-xs font-bold transition-all disabled:opacity-50"
          >
            <Sparkles className="h-3.5 w-3.5 text-teal-500" />
            Lancer l'analyse Gemini
          </button>
        </div>
      </div>

      <div className="lg:col-span-6 flex flex-col justify-between">
        {!analysisResult && !errorText && (
          <div className="flex-1 bg-slate-950/40 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-bold font-mono text-slate-500 uppercase flex items-center gap-1.5 mb-3">
                <Eye className="h-3.5 w-3.5" /> Scénarios de Test Virtuels
              </h4>
              <div className="space-y-2">
                {PRESETS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setActivePresetId(p.id);
                      setUseWebcam(false);
                      setAnalysisResult(null);
                    }}
                    className={`w-full p-2.5 text-left rounded-xl border text-xs transition-all ${
                      activePresetId === p.id && !useWebcam
                        ? "bg-teal-950/25 border-teal-500/40 text-white font-medium"
                        : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800"
                    }`}
                  >
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="font-bold">{p.name}</span>
                      <span className="text-[8px] font-mono font-bold px-1 rounded bg-slate-950 text-emerald-400">{p.rating}</span>
                    </div>
                    <p className="text-[10px] text-slate-500 truncate">{p.desc}</p>
                  </button>
                ))}
              </div>
            </div>
            <p className="text-[10px] text-slate-500 font-mono text-center mt-3 leading-relaxed">
              * Pressez "Lancer l'analyse Gemini" pour déclencher le décryptage d'images.
            </p>
          </div>
        )}

        {errorText && (
          <div className="flex-1 bg-red-950/20 border border-red-500/20 rounded-2xl p-5 text-center flex flex-col items-center justify-center">
            <XOctagon className="h-8 w-8 text-red-500 mb-2" />
            <h4 className="text-xs font-bold text-red-400">Erreur d'auscultation</h4>
            <p className="text-[11px] text-red-300 max-w-xs mt-1">{errorText}</p>
            <button onClick={triggerAiAnalysis} className="mt-3 px-3.5 py-1.5 bg-red-650 rounded-lg text-xs font-bold">Réessayer</button>
          </div>
        )}

        {analysisResult && (
          <div className="flex-1 bg-slate-950/70 border border-teal-500/10 rounded-2xl p-4 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-2 mb-3">
                <span className="text-xs font-bold text-emerald-400 font-mono">BILAN DE SOMMEIL</span>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400">{analysisResult.safetyRating}</span>
              </div>

              <div className="space-y-3 text-xs text-slate-350 max-h-[180px] overflow-y-auto pr-1">
                <div>
                  <span className="text-[9px] font-mono text-slate-500 block">Position corporelle :</span>
                  <p className="text-xs text-white p-0.5 mt-0.5 font-medium">{analysisResult.postureText}</p>
                </div>
                <div>
                  <span className="text-[9px] font-mono text-slate-500 block">Lit :</span>
                  <p className="text-xs text-slate-300 p-0.5 mt-0.5">{analysisResult.cribAssoc}</p>
                </div>
                <div className="p-2.5 bg-emerald-950/25 rounded-lg border border-emerald-500/10 text-emerald-250">
                  <span className="text-[9px] font-mono text-emerald-450 block font-bold">Conseil :</span>
                  <p className="text-[11px] mt-0.5">{analysisResult.environmentalAdvice}</p>
                </div>
              </div>
            </div>

            <div className="mt-3 pt-2.5 border-t border-slate-850 flex justify-between items-center text-[11px]">
              <span className="text-slate-500 font-mono">Statut : {analysisResult.estimatedState}</span>
              <button onClick={() => setAnalysisResult(null)} className="text-emerald-400 font-mono text-[10px]">Retour ↩</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
