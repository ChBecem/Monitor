import React, { useEffect, useRef, useState } from "react";
import { Play, Pause, Disc, Waves, Heart, Music, Timer, Volume2, VolumeX, Sparkles } from "lucide-react";

// Support both Twinkle and Brahms chime melodies
export type LullabySound = "none" | "pink_noise" | "heartbeat" | "twinkle" | "brahms";

interface LullabyPlayerProps {
  activeSound?: LullabySound;
  volumePercent?: number;
  timerMinutes?: number | null;
  onSoundChange?: (sound: LullabySound) => void;
  onVolumeChange?: (vol: number) => void;
  onTimerChange?: (mins: number | null) => void;
  isBabyStationControl?: boolean; // If true, this component plays sounds automatically based on activeSound prop
}

export default function LullabyPlayer({
  activeSound = "none",
  volumePercent = 50,
  timerMinutes = null,
  onSoundChange,
  onVolumeChange,
  onTimerChange,
  isBabyStationControl = false
}: LullabyPlayerProps) {
  // Fallbacks for local state if props are omitted
  const [localActiveSound, setLocalActiveSound] = useState<LullabySound>("none");
  const [localVolume, setLocalVolume] = useState(50);
  const [localTimerPreset, setLocalTimerPreset] = useState<number | null>(null);
  const [timerLeft, setTimerLeft] = useState<number | null>(null);

  const sound = onSoundChange ? activeSound : localActiveSound;
  const vol = onVolumeChange ? volumePercent : localVolume;
  const timerPreset = onTimerChange ? timerMinutes : localTimerPreset;

  const audioCtxRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const heartbeatIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const melodyIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Sync internal countdown
  useEffect(() => {
    if (timerPreset !== null) {
      setTimerLeft(timerPreset * 60);
    } else {
      setTimerLeft(null);
    }
  }, [timerPreset]);

  // Countdown ticking
  useEffect(() => {
    if (timerLeft !== null) {
      if (timerLeft <= 0) {
        handleStopAll();
        setTimerLeft(null);
        if (onTimerChange) onTimerChange(null);
        else setLocalTimerPreset(null);
      } else {
        countdownIntervalRef.current = setTimeout(() => {
          setTimerLeft((p) => (p !== null ? p - 1 : null));
        }, 1000);
      }
    }
    return () => {
      if (countdownIntervalRef.current) clearTimeout(countdownIntervalRef.current);
    };
  }, [timerLeft]);

  // Playback sound dynamic switch
  useEffect(() => {
    // If Baby station is commanding, we should synthesize audio here
    // Or if we are in local manual mode
    if (sound === "none") {
      stopAllSynth();
    } else if (sound === "pink_noise") {
      startPinkNoise();
    } else if (sound === "heartbeat") {
      startHeartbeat();
    } else if (sound === "twinkle") {
      startMelody("twinkle");
    } else if (sound === "brahms") {
      startMelody("brahms");
    }

    return () => {
      stopAllSynth();
    };
  }, [sound]);

  // Real-time volume scaling
  useEffect(() => {
    if (gainNodeRef.current) {
      const targetVolume = (vol / 100) * 0.45;
      gainNodeRef.current.gain.setValueAtTime(targetVolume, audioCtxRef.current?.currentTime || 0);
    }
  }, [vol]);

  const initCtx = () => {
    if (!audioCtxRef.current) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      audioCtxRef.current = new AudioCtxClass();
    }
    if (audioCtxRef.current.state === "suspended") {
      audioCtxRef.current.resume();
    }
  };

  const stopAllSynth = () => {
    if (sourceNodeRef.current) {
      try { sourceNodeRef.current.stop(); } catch (e) {}
      sourceNodeRef.current = null;
    }
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
      heartbeatIntervalRef.current = null;
    }
    if (melodyIntervalRef.current) {
      clearInterval(melodyIntervalRef.current);
      melodyIntervalRef.current = null;
    }
  };

  const handleStopAll = () => {
    stopAllSynth();
    if (onSoundChange) onSoundChange("none");
    else setLocalActiveSound("none");
  };

  const startPinkNoise = () => {
    stopAllSynth();
    initCtx();
    const ctx = audioCtxRef.current!;

    // Create custom White noise buffer and shape to soft ocean-wave lowpass
    const bufferSize = ctx.sampleRate * 2; 
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const outputChannel = noiseBuffer.getChannelData(0);

    let b0 = 0.0, b1 = 0.0, b2 = 0.0, b3 = 0.0, b4 = 0.0, b5 = 0.0, b6 = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      const pink = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
      b6 = white * 0.115926;
      outputChannel[i] = pink * 0.12; 
    }

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    // Soft cozy lowpass filter to imitate fetal fluid/rain
    const lowpass = ctx.createBiquadFilter();
    lowpass.type = "lowpass";
    lowpass.frequency.value = 550; 
    lowpass.Q.value = 1;

    const gainNode = ctx.createGain();
    gainNode.gain.value = (vol / 100) * 0.45;
    gainNodeRef.current = gainNode;

    noiseSource.connect(lowpass);
    lowpass.connect(gainNode);
    gainNode.connect(ctx.destination);

    noiseSource.start(0);
    sourceNodeRef.current = noiseSource;
  };

  const startHeartbeat = () => {
    stopAllSynth();
    initCtx();
    const ctx = audioCtxRef.current!;

    const gainNode = ctx.createGain();
    gainNode.gain.value = (vol / 100) * 0.4;
    gainNodeRef.current = gainNode;
    gainNode.connect(ctx.destination);

    const playWombBeat = () => {
      const t = ctx.currentTime;
      // Double heart sync pulse
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.frequency.setValueAtTime(58, t);
      osc1.frequency.exponentialRampToValueAtTime(10, t + 0.15);
      gain1.gain.setValueAtTime(0.75, t);
      gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

      osc1.connect(gain1);
      gain1.connect(gainNode);
      osc1.start(t);
      osc1.stop(t + 0.17);

      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.frequency.setValueAtTime(54, t + 0.2);
      osc2.frequency.exponentialRampToValueAtTime(10, t + 0.35);
      gain2.gain.setValueAtTime(0.55, t + 0.2);
      gain2.gain.exponentialRampToValueAtTime(0.001, t + 0.36);

      osc2.connect(gain2);
      gain2.connect(gainNode);
      osc2.start(t + 0.2);
      osc2.stop(t + 0.38);
    };

    playWombBeat();
    heartbeatIntervalRef.current = setInterval(playWombBeat, 910); // 66 BPM womb pulsations
  };

  const startMelody = (melodyType: "twinkle" | "brahms") => {
    stopAllSynth();
    initCtx();
    const ctx = audioCtxRef.current!;

    const gainNode = ctx.createGain();
    gainNode.gain.value = (vol / 100) * 0.3;
    gainNodeRef.current = gainNode;
    gainNode.connect(ctx.destination);

    const twinkleNotes = [
      261.63, 261.63, 392.00, 392.00, 440.00, 440.00, 392.00, // Twinkle Twinkle Little Star
      349.23, 349.23, 329.63, 329.63, 293.66, 293.66, 261.63
    ];

    const brahmsNotes = [
      329.63, 329.63, 392.00, 329.63, 392.00, // Lullaby and good night
      329.63, 392.00, 523.25, 493.88, 440.00, 392.00,
      293.66, 329.63, 349.23, 293.66, 349.23,
      293.66, 349.23, 493.88, 440.00, 392.00, 523.25
    ];

    const notes = melodyType === "twinkle" ? twinkleNotes : brahmsNotes;
    let index = 0;

    const playChimeNote = () => {
      const t = ctx.currentTime;
      const freq = notes[index];
      index = (index + 1) % notes.length;

      const osc = ctx.createOscillator();
      const overtone = ctx.createOscillator();
      const noteGain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, t);

      overtone.type = "sine";
      overtone.frequency.setValueAtTime(freq * 2, t); // High harmonics

      noteGain.gain.setValueAtTime(0.6, t);
      noteGain.gain.exponentialRampToValueAtTime(0.001, t + 0.85);

      osc.connect(noteGain);
      overtone.connect(noteGain);
      noteGain.connect(gainNode);

      osc.start(t);
      overtone.start(t);
      osc.stop(t + 0.9);
      overtone.stop(t + 0.9);
    };

    playChimeNote();
    melodyIntervalRef.current = setInterval(playChimeNote, 950);
  };

  const selectSound = (type: LullabySound) => {
    if (onSoundChange) {
      onSoundChange(type);
    } else {
      setLocalActiveSound(type);
    }
  };

  const handlePresetClick = (presetMins: number) => {
    if (onTimerChange) {
      onTimerChange(timerPreset === presetMins ? null : presetMins);
    } else {
      const nextPreset = localTimerPreset === presetMins ? null : presetMins;
      setLocalTimerPreset(nextPreset);
    }
  };

  const getTimerDisplay = () => {
    if (timerLeft === null) return null;
    const m = Math.floor(timerLeft / 60);
    const s = timerLeft % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  // If running in background for Baby Station to play local audio, we render a minimal HUD
  if (isBabyStationControl) {
    return (
      <div className="bg-slate-900/80 border border-teal-500/30 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-teal-500/10 rounded-xl text-teal-400 border border-teal-500/20">
            <Disc className={`h-5 w-5 ${sound !== "none" ? "animate-spin" : ""}`} />
          </div>
          <div>
            <h4 className="text-xs font-bold font-mono text-emerald-400">DIFFUSEUR APPAREIL BÉBÉ</h4>
            <p className="text-[11px] text-slate-300 capitalize">
              {sound === "none" ? "Silencieux" : `Diffusion active : ${sound === "twinkle" ? "Twinkle" : sound}`}
            </p>
          </div>
        </div>
        {sound !== "none" && (
          <div className="flex items-center gap-2">
            <Volume2 className="h-4 w-4 text-emerald-500 animate-pulse" />
            <span className="text-xs font-mono text-slate-400">{vol}%</span>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl h-full flex flex-col justify-between" id="lullaby-component">
      <div>
        <span className="text-xs font-mono uppercase tracking-widest text-[#10b981]">Apaisement pédiatrique</span>
        <h3 className="text-lg font-bold tracking-tight mt-0.5 mb-4">Diffuseur de Berceuses</h3>

        {/* Active state visualization */}
        <div className="flex justify-center my-4">
          <div className="relative">
            {sound !== "none" && (
              <>
                <span className="absolute -inset-4 bg-emerald-500/10 rounded-full animate-ping opacity-60" />
                <span className="absolute -inset-8 bg-emerald-500/5 rounded-full animate-pulse opacity-40" />
              </>
            )}
            <div className={`p-6 rounded-full border transition-all duration-300 ${
              sound !== "none"
                ? "bg-emerald-950/40 border-emerald-500/40 text-emerald-400"
                : "bg-slate-950 border-slate-800/80 text-slate-600"
            }`}>
              <Disc className={`h-8 w-8 ${sound !== "none" ? "animate-spin" : ""}`} />
            </div>
          </div>
        </div>

        {/* Playback choices */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          <button
            onClick={() => selectSound(sound === "twinkle" ? "none" : "twinkle")}
            className={`flex items-center gap-2.5 p-3 rounded-xl border text-left text-xs transition-all ${
              sound === "twinkle"
                ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-bold"
                : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800"
            }`}
          >
            <Music className="h-4 w-4 shrink-0 text-emerald-400" />
            <div className="truncate">
              <span className="block font-semibold">Ah vous dirais-je</span>
              <span className="text-[9px] opacity-60 font-mono block">Twinkle twinkle</span>
            </div>
          </button>

          <button
            onClick={() => selectSound(sound === "brahms" ? "none" : "brahms")}
            className={`flex items-center gap-2.5 p-3 rounded-xl border text-left text-xs transition-all ${
              sound === "brahms"
                ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-bold"
                : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800"
            }`}
          >
            <Sparkles className="h-4 w-4 shrink-0 text-amber-400" />
            <div className="truncate">
              <span className="block font-semibold">Brahms Berceuse</span>
              <span className="text-[9px] opacity-60 font-mono block">Mélodie douce</span>
            </div>
          </button>

          <button
            onClick={() => selectSound(sound === "pink_noise" ? "none" : "pink_noise")}
            className={`flex items-center gap-2.5 p-3 rounded-xl border text-left text-xs transition-all ${
              sound === "pink_noise"
                ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-bold"
                : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800"
            }`}
          >
            <Waves className="h-4 w-4 shrink-0 text-sky-400" />
            <div className="truncate">
              <span className="block font-semibold">Bruit Rose</span>
              <span className="text-[9px] opacity-60 font-mono block">Filtre 550Hz</span>
            </div>
          </button>

          <button
            onClick={() => selectSound(sound === "heartbeat" ? "none" : "heartbeat")}
            className={`flex items-center gap-2.5 p-3 rounded-xl border text-left text-xs transition-all ${
              sound === "heartbeat"
                ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-bold"
                : "bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800"
            }`}
          >
            <Heart className="h-4 w-4 shrink-0 text-red-400 animate-pulse" />
            <div className="truncate">
              <span className="block font-semibold">Battement Fœtal</span>
              <span className="text-[9px] opacity-60 font-mono block">Uterus 66 BPM</span>
            </div>
          </button>
        </div>

        {/* Volume controls */}
        <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-3.5 mb-4">
          <div className="flex justify-between items-center text-xs font-mono text-slate-500 mb-1.5">
            <span>Intensité sonore</span>
            <span className="text-white font-bold">{vol}%</span>
          </div>
          <div className="flex items-center gap-2.5">
            <VolumeX className="h-4 w-4 text-slate-600" />
            <input
              type="range"
              min="0"
              max="100"
              value={vol}
              onChange={(e) => onVolumeChange ? onVolumeChange(parseInt(e.target.value)) : setLocalVolume(parseInt(e.target.value))}
              className="flex-1 accent-emerald-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Timer settings */}
      <div className="pt-3 border-t border-slate-800/80">
        <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
          <span>Minuteur dodo</span>
          {getTimerDisplay() ? (
            <span className="text-emerald-400 font-bold bg-emerald-950/40 border border-emerald-500/20 px-2 py-0.5 rounded-md text-[10.5px]">
              ⏱ {getTimerDisplay()}
            </span>
          ) : (
            <span className="text-slate-500 text-[10px]">Infini ♾</span>
          )}
        </div>

        <div className="flex gap-1.5">
          {[1, 5, 15, 30].map((preset) => (
            <button
              key={preset}
              onClick={() => handlePresetClick(preset)}
              className={`flex-1 py-1 text-[10px] font-mono rounded-lg border transition-all ${
                timerPreset === preset
                  ? "bg-emerald-600 border-emerald-500 text-white font-bold"
                  : "bg-slate-950 border-slate-800 text-slate-500 hover:bg-slate-800 hover:text-slate-350"
              }`}
            >
              {preset}m
            </button>
          ))}
          {timerPreset !== null && (
            <button
              onClick={() => onTimerChange ? onTimerChange(null) : setLocalTimerPreset(null)}
              className="px-2 py-1 bg-red-950/20 border border-red-500/20 text-red-400 hover:bg-red-900/20 rounded-lg text-[9.5px] font-mono shrink-0"
            >
              Stop
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
