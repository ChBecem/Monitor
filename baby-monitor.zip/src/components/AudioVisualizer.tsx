import React, { useEffect, useRef, useState } from "react";
import { Mic, MicOff, AlertCircle, HardDrive, Volume2 } from "lucide-react";

interface AudioVisualizerProps {
  onAlertTriggered?: (dB: number) => void;
  isBabyCryingSimulated?: boolean;
  onCryingStateChange?: (isCrying: boolean) => void;
  onDecibelUpdate?: (dB: number) => void; // Sync decibels with server-side room
  isBabyStationView?: boolean;
}

export default function AudioVisualizer({
  onAlertTriggered,
  isBabyCryingSimulated = false,
  onCryingStateChange,
  onDecibelUpdate,
  isBabyStationView = false
}: AudioVisualizerProps) {
  const [isMonitoring, setIsMonitoring] = useState(true);
  const [decibel, setDecibel] = useState(32);
  const [threshold, setThreshold] = useState(65);
  const [alertActive, setAlertActive] = useState(false);
  const [micStateError, setMicStateError] = useState<string | null>(null);
  const [useSimulatedAudio, setUseSimulatedAudio] = useState(true);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const dataArrayRef = useRef<Uint8Array | null>(null);
  const animationFrameId = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const criticalTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Poll simulated room volume fluctuations or respond to cry overrides
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (useSimulatedAudio && isMonitoring) {
      interval = setInterval(() => {
        let baseNoise = 30 + Math.random() * 8;
        if (isBabyCryingSimulated) {
          baseNoise = 75 + Math.random() * 12;
        }
        const finalDb = Math.round(baseNoise);
        setDecibel(finalDb);
        if (onDecibelUpdate) onDecibelUpdate(finalDb);
      }, 200);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [useSimulatedAudio, isMonitoring, isBabyCryingSimulated]);

  // Handle Threshold & Alert generation
  useEffect(() => {
    if (!isMonitoring) return;

    if (decibel >= threshold) {
      if (!criticalTimerRef.current) {
        criticalTimerRef.current = setTimeout(() => {
          setAlertActive(true);
          if (onAlertTriggered) onAlertTriggered(decibel);
          if (onCryingStateChange) onCryingStateChange(true);
        }, 1200); // sound must stay loud for 1.2s to declare a true alert
      }
    } else {
      if (criticalTimerRef.current) {
        clearTimeout(criticalTimerRef.current);
        criticalTimerRef.current = null;
      }
      if (decibel < threshold - 6) { // squelch band prevents flickering
        setAlertActive(false);
        if (onCryingStateChange) onCryingStateChange(false);
      }
    }
  }, [decibel, threshold, isMonitoring]);

  // Live wave visualizer drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let frameId: number;

    const renderWave = () => {
      frameId = requestAnimationFrame(renderWave);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!isMonitoring) {
        // Draw flat line
        ctx.strokeStyle = "#475569";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, canvas.height / 2);
        ctx.lineTo(canvas.width, canvas.height / 2);
        ctx.stroke();
        return;
      }

      const activeColor = alertActive ? "#f43f5e" : "#10b981";
      ctx.strokeStyle = activeColor;
      ctx.lineWidth = 3;

      if (!useSimulatedAudio && analyserRef.current && dataArrayRef.current) {
        analyserRef.current.getByteTimeDomainData(dataArrayRef.current);
        const len = analyserRef.current.frequencyBinCount;
        ctx.beginPath();
        const sliceWidth = canvas.width / len;
        let x = 0;

        for (let i = 0; i < len; i++) {
          const v = dataArrayRef.current[i] / 128.0;
          const y = (v * canvas.height) / 2;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
          x += sliceWidth;
        }
        ctx.lineTo(canvas.width, canvas.height / 2);
        ctx.stroke();
      } else {
        // Generate beautiful sine wave graphics
        ctx.beginPath();
        const t = Date.now() * 0.007;
        const amp = isBabyCryingSimulated ? 18 : 5;

        for (let i = 0; i < canvas.width; i++) {
          const wave1 = Math.sin(i * 0.02 + t) * amp;
          const wave2 = Math.cos(i * 0.04 - t * 0.5) * (amp * 0.5);
          const y = canvas.height / 2 + wave1 + wave2;

          if (i === 0) ctx.moveTo(i, y);
          else ctx.lineTo(i, y);
        }
        ctx.stroke();

        // Overlay transparent companion wave
        ctx.beginPath();
        ctx.strokeStyle = alertActive ? "rgba(244, 63, 94, 0.25)" : "rgba(16, 185, 129, 0.25)";
        ctx.lineWidth = 1;
        for (let i = 0; i < canvas.width; i++) {
          const y = canvas.height / 2 + Math.sin(i * 0.035 - t * 0.7) * (amp * 0.8);
          if (i === 0) ctx.moveTo(i, y);
          else ctx.lineTo(i, y);
        }
        ctx.stroke();
      }
    };

    renderWave();
    return () => cancelAnimationFrame(frameId);
  }, [isMonitoring, useSimulatedAudio, decibel, alertActive, isBabyCryingSimulated]);

  const toggleMonitoring = async () => {
    if (isMonitoring) {
      stopMicrophone();
      setIsMonitoring(false);
      setAlertActive(false);
      if (onCryingStateChange) onCryingStateChange(false);
    } else {
      setIsMonitoring(true);
      if (!useSimulatedAudio) {
        await startMicrophone();
      }
    }
  };

  const startMicrophone = async () => {
    try {
      setMicStateError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      streamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);

      analyserRef.current = analyser;
      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      dataArrayRef.current = dataArray;

      const checkVolume = () => {
        if (!analyserRef.current || !isMonitoring) return;
        const tempArray = new Uint8Array(analyserRef.current.fftSize);
        analyserRef.current.getByteTimeDomainData(tempArray);

        let sum = 0;
        for (let i = 0; i < tempArray.length; i++) {
          const normalized = (tempArray[i] - 128) / 128;
          sum += normalized * normalized;
        }
        const rms = Math.sqrt(sum / tempArray.length);
        const computedDb = rms > 0 ? Math.round(20 * Math.log10(rms) + 85) : 30;
        const cappedDb = Math.max(30, Math.min(110, computedDb));

        setDecibel(cappedDb);
        if (onDecibelUpdate) onDecibelUpdate(cappedDb);

        if (isMonitoring && !useSimulatedAudio) {
          setTimeout(checkVolume, 120);
        }
      };

      setTimeout(checkVolume, 120);
    } catch (e) {
      console.warn("Could not capture physical micro audio.", e);
      setUseSimulatedAudio(true);
      setMicStateError("Micro physique refusé. Simulation auto.");
    }
  };

  const stopMicrophone = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== "closed") {
      audioContextRef.current.close();
    }
    analyserRef.current = null;
  };

  const flipSimulatedAudio = () => {
    if (useSimulatedAudio) {
      setUseSimulatedAudio(false);
      startMicrophone();
    } else {
      stopMicrophone();
      setUseSimulatedAudio(true);
    }
  };

  return (
    <div className={`bg-slate-900 border border-slate-800 rounded-3xl p-6 transition-all relative overflow-hidden ${
      alertActive ? "ring-2 ring-rose-500/30" : ""
    }`} id="acoustic-sensor">
      {alertActive && (
        <div className="absolute inset-0 bg-rose-950/10 pointer-events-none animate-pulse" />
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-widest text-[#10b981]">CAPTEUR ACOUSTIQUE</span>
          <h3 className="text-lg font-bold tracking-tight mt-0.5">Décibels & Ondes de la Chambre</h3>
        </div>

        <div className="flex items-center gap-2">
          {!isBabyStationView && (
            <button
              onClick={() => onCryingStateChange && onCryingStateChange(!isBabyCryingSimulated)}
              className={`px-3 py-1.5 rounded-full text-[11px] font-mono transition-all ${
                isBabyCryingSimulated
                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold animate-pulse"
                  : "bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-350"
              }`}
            >
              👶 {isBabyCryingSimulated ? "Arrêter Cris" : "Injecter Cris"}
            </button>
          )}

          <button
            onClick={toggleMonitoring}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all ${
              isMonitoring
                ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/30"
                : "bg-slate-950 border border-slate-800 text-slate-300"
            }`}
          >
            {isMonitoring ? (
              <>
                <Mic className="h-3.5 w-3.5 animate-pulse" /> Écoute active
              </>
            ) : (
              <>
                <MicOff className="h-3.5 w-3.5" /> Ré-écouter
              </>
            )}
          </button>
        </div>
      </div>

      {micStateError && (
        <div className="bg-amber-950/20 border border-amber-500/20 rounded-xl p-2.5 mb-3.5 text-[11px] text-amber-300 flex items-center gap-2">
          <Volume2 className="h-3.5 w-3.5 text-amber-400" />
          <span>{micStateError}</span>
        </div>
      )}

      {/* Grid Display readout representation */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
        <div className="col-span-1 md:col-span-4 bg-slate-950/40 border border-slate-800/85 p-4 rounded-2xl flex flex-col justify-between">
          <div className="text-[10px] font-mono uppercase text-slate-500">Amplitude Instannée</div>
          <div className="my-2 flex items-baseline gap-1">
            <span className={`text-4xl font-extrabold font-mono tracking-tight transition-colors ${
              decibel >= threshold ? "text-rose-500" : "text-emerald-400"
            }`}>
              {decibel}
            </span>
            <span className="text-xs text-slate-500 font-mono">dBA</span>
          </div>

          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden relative mt-1">
            <div
              className={`h-full rounded-full transition-all duration-150 ${
                decibel >= threshold ? "bg-rose-500" : "bg-emerald-500"
              }`}
              style={{ width: `${Math.min(100, Math.max(0, ((decibel - 30) / (110 - 30)) * 100))}%` }}
            />
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-yellow-500"
              style={{ left: `${((threshold - 30) / (110 - 30)) * 100}%` }}
            />
          </div>
          <div className="flex justify-between text-[8.5px] font-mono text-slate-500 mt-1">
            <span>Calme (30)</span>
            <span className="text-yellow-500 font-bold">Seuil ({threshold})</span>
            <span>Saturé (110)</span>
          </div>
        </div>

        {/* Oscilloscope visual Canvas */}
        <div className="col-span-1 md:col-span-8 bg-slate-950 border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between relative">
          <div className="absolute top-2 left-3 text-[9px] font-mono text-slate-600">CAPTEUR AUDIO ANALOGIQUE</div>
          <div className="absolute top-2 right-3 flex items-center gap-1">
            <span className={`h-1.5 w-1.5 rounded-full ${isMonitoring ? "bg-emerald-400" : "bg-slate-600"}`} />
            <span className="text-[9px] font-mono text-slate-500">{isMonitoring ? "FM STEREO" : "OFFLINE"}</span>
          </div>

          <div className="h-20 w-full flex items-center justify-center mt-2.5">
            <canvas ref={canvasRef} width={450} height={80} className="w-full h-full block" />
          </div>
        </div>
      </div>

      {/* Sliding Control Bar */}
      <div className="mt-5 pt-3.5 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex-1 w-full">
          <div className="flex justify-between items-center text-xs font-mono text-slate-400 mb-1">
            <span>Sensibilité d'alerte : <strong>{threshold} dBA</strong></span>
            <span className="text-slate-500 text-[10px]">Détection déclenchée au-delà</span>
          </div>
          <input
            type="range"
            min="45"
            max="95"
            value={threshold}
            onChange={(e) => setThreshold(parseInt(e.target.value))}
            className="w-full accent-emerald-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        <button
          onClick={flipSimulatedAudio}
          className="flex items-center gap-2 text-xs px-3.5 py-1.5 bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 text-slate-400 transition-all font-mono shrink-0"
        >
          <HardDrive className="h-3.5 w-3.5" />
          {useSimulatedAudio ? "Mode Micro" : "Mode Simulation"}
        </button>
      </div>

      {alertActive && (
        <div className="mt-4 bg-rose-950/20 border border-rose-500/30 text-rose-300 p-3.5 rounded-2xl flex items-center gap-3.5 text-xs animate-bounce">
          <div className="p-2 bg-rose-600 rounded-xl text-white font-mono font-bold">🚨</div>
          <div>
            <p className="font-bold">Alerte active : Berceau bruyant !</p>
            <p className="opacity-80 text-[11px] mt-0.5">Le son ambiant excède votre limite de {threshold} dBA. Bébé pourrait s'être réveillé.</p>
          </div>
        </div>
      )}
    </div>
  );
}
