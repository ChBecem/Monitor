package com.devoteam.babymonitor;

import android.Manifest;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

@CapacitorPlugin(
    name = "AppPermissions",
    permissions = {
        @Permission(
            alias = "camera",
            strings = { Manifest.permission.CAMERA }
        ),
        @Permission(
            alias = "microphone",
            strings = { Manifest.permission.RECORD_AUDIO }
        )
    }
)
public class AppPermissionsPlugin extends Plugin {

    @PluginMethod
    public void requestAllPermissions(PluginCall call) {
        if (getPermissionState("camera") != com.getcapacitor.PermissionState.GRANTED ||
            getPermissionState("microphone") != com.getcapacitor.PermissionState.GRANTED) {
            
            requestPermissionForAliases(new String[]{"camera", "microphone"}, call, "permissionsCallback");
        } else {
            JSObject response = new JSObject();
            response.put("camera", "granted");
            response.put("microphone", "granted");
            call.resolve(response);
        }
    }

    @PermissionCallback
    public void permissionsCallback(PluginCall call) {
        JSObject response = new JSObject();
        response.put("camera", getPermissionState("camera").toString());
        response.put("microphone", getPermissionState("microphone").toString());
        call.resolve(response);
    }
}
